module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/lib/api/data.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * 数据访问层
 */ __turbopack_context__.s([
    "getContactSubmissionCount",
    ()=>getContactSubmissionCount,
    "getProjectBySlug",
    ()=>getProjectBySlug,
    "getProjects",
    ()=>getProjects,
    "saveContactSubmission",
    ()=>saveContactSubmission
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
const PROJECTS_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), 'data', 'projects.json');
async function getProjects() {
    try {
        const fileContent = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(PROJECTS_FILE, 'utf-8');
        return JSON.parse(fileContent);
    } catch (error) {
        console.error('Failed to read projects.json:', error);
        return [];
    }
}
async function getProjectBySlug(slug) {
    const projects = await getProjects();
    return projects.find((p)=>p.slug === slug) || null;
}
const contactSubmissions = [];
function saveContactSubmission(data) {
    const submission = {
        id: `contact_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        ...data,
        createdAt: new Date().toISOString()
    };
    contactSubmissions.push(submission);
    // 可选：追加到文件（用于持久化）
    // 生产环境建议使用数据库
    return submission;
}
function getContactSubmissionCount() {
    return contactSubmissions.length;
}
}),
"[project]/lib/api/schemas.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Zod 校验 Schema
 */ __turbopack_context__.s([
    "contactRequestSchema",
    ()=>contactRequestSchema,
    "projectSlugSchema",
    ()=>projectSlugSchema,
    "projectsQuerySchema",
    ()=>projectsQuerySchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
;
const contactRequestSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().min(1, '姓名不能为空').max(50, '姓名不能超过50个字符'),
    email: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().email('邮箱格式不正确'),
    message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().min(10, '消息内容至少10个字符').max(2000, '消息内容不能超过2000个字符')
});
const projectsQuerySchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    category: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
        '数字孪生',
        '可视化',
        'AI 应用',
        '全部'
    ]).optional(),
    search: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional(),
    page: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.number().int().min(1).default(1).optional(),
    limit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.number().int().min(1).max(50).default(10).optional()
});
const projectSlugSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    slug: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().min(1, '项目标识不能为空')
});
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/lib/api/types.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * API 共享类型定义
 */ // ========== 统一响应格式 ==========
__turbopack_context__.s([
    "ErrorCodes",
    ()=>ErrorCodes
]);
const ErrorCodes = {
    VALIDATION_ERROR: 'VALIDATION_ERROR',
    NOT_FOUND: 'NOT_FOUND',
    RATE_LIMIT: 'RATE_LIMIT',
    INTERNAL_ERROR: 'INTERNAL_ERROR'
};
}),
"[project]/lib/api/response.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * 统一响应工具函数
 */ __turbopack_context__.s([
    "errorResponse",
    ()=>errorResponse,
    "internalErrorResponse",
    ()=>internalErrorResponse,
    "notFoundResponse",
    ()=>notFoundResponse,
    "rateLimitResponse",
    ()=>rateLimitResponse,
    "successResponse",
    ()=>successResponse,
    "validationErrorResponse",
    ()=>validationErrorResponse
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/types.ts [app-route] (ecmascript)");
;
;
function successResponse(data, status = 200) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        success: true,
        data
    }, {
        status
    });
}
function errorResponse(code, message, status = 400, details) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        success: false,
        error: {
            code,
            message,
            ...("TURBOPACK compile-time value", "development") === 'development' && details ? {
                details
            } : {}
        }
    }, {
        status
    });
}
function validationErrorResponse(message, details) {
    return errorResponse(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ErrorCodes"].VALIDATION_ERROR, message, 400, details);
}
function notFoundResponse(message = '资源不存在') {
    return errorResponse(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ErrorCodes"].NOT_FOUND, message, 404);
}
function rateLimitResponse(message = '请求过于频繁，请稍后再试') {
    return errorResponse(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ErrorCodes"].RATE_LIMIT, message, 429);
}
function internalErrorResponse(message = '服务器内部错误', details) {
    return errorResponse(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ErrorCodes"].INTERNAL_ERROR, message, 500, details);
}
}),
"[project]/app/api/projects/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * GET /api/projects
 * 项目列表接口（支持筛选、搜索、分页）
 */ __turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$data$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/data.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$schemas$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/schemas.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/response.ts [app-route] (ecmascript)");
;
;
;
async function GET(request) {
    try {
        // 解析查询参数
        const searchParams = request.nextUrl.searchParams;
        const query = {
            category: searchParams.get('category') || undefined,
            search: searchParams.get('search') || undefined,
            page: searchParams.get('page') || undefined,
            limit: searchParams.get('limit') || undefined
        };
        // 校验查询参数
        const validationResult = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$schemas$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["projectsQuerySchema"].safeParse(query);
        if (!validationResult.success) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["validationErrorResponse"])('查询参数格式错误', validationResult.error.issues);
        }
        const { category, search, page = 1, limit = 10 } = validationResult.data;
        // 获取所有项目
        const allProjects = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$data$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getProjects"])();
        // 筛选：类别
        let filteredProjects = allProjects;
        if (category && category !== '全部') {
            filteredProjects = filteredProjects.filter((p)=>p.category === category);
        }
        // 筛选：搜索关键词（标题、描述、标签）
        if (search && search.trim()) {
            const searchLower = search.toLowerCase().trim();
            filteredProjects = filteredProjects.filter((p)=>{
                const titleMatch = p.title.toLowerCase().includes(searchLower);
                const descMatch = p.description.toLowerCase().includes(searchLower);
                const tagsMatch = p.tags.some((tag)=>tag.toLowerCase().includes(searchLower));
                return titleMatch || descMatch || tagsMatch;
            });
        }
        // 分页
        const total = filteredProjects.length;
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + limit;
        const paginatedProjects = filteredProjects.slice(startIndex, endIndex);
        // 转换为列表格式（不包含详情字段）
        const items = paginatedProjects.map((p)=>({
                id: p.id,
                slug: p.slug,
                title: p.title,
                description: p.description,
                tags: p.tags,
                category: p.category,
                thumbnailUrl: p.thumbnailUrl,
                createdAt: p.createdAt,
                updatedAt: p.updatedAt
            }));
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["successResponse"])({
            items,
            total,
            page,
            limit
        });
    } catch (error) {
        console.error('GET /api/projects error:', error);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["internalErrorResponse"])('获取项目列表失败', error);
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__d90d3bff._.js.map