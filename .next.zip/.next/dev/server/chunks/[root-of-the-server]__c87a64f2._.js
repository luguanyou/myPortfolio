module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/lib/api/schemas.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Zod 校验 Schema
 */ __turbopack_context__.s([
    "contactRequestSchema",
    ()=>contactRequestSchema,
    "projectSlugSchema",
    ()=>projectSlugSchema,
    "projectsQuerySchema",
    ()=>projectsQuerySchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
;
const contactRequestSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().min(1, '姓名不能为空').max(50, '姓名不能超过50个字符'),
    email: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().email('邮箱格式不正确'),
    message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().min(10, '消息内容至少10个字符').max(2000, '消息内容不能超过2000个字符')
});
const projectsQuerySchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    category: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
        '数字孪生',
        '可视化',
        'AI 应用',
        '全部'
    ]).optional(),
    search: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional(),
    page: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.number().int().min(1).default(1).optional(),
    limit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.number().int().min(1).max(50).default(10).optional()
});
const projectSlugSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    slug: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().min(1, '项目标识不能为空')
});
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/lib/api/types.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * API 共享类型定义
 */ // ========== 统一响应格式 ==========
__turbopack_context__.s([
    "ErrorCodes",
    ()=>ErrorCodes
]);
const ErrorCodes = {
    VALIDATION_ERROR: 'VALIDATION_ERROR',
    NOT_FOUND: 'NOT_FOUND',
    RATE_LIMIT: 'RATE_LIMIT',
    INTERNAL_ERROR: 'INTERNAL_ERROR'
};
}),
"[project]/lib/api/response.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * 统一响应工具函数
 */ __turbopack_context__.s([
    "errorResponse",
    ()=>errorResponse,
    "internalErrorResponse",
    ()=>internalErrorResponse,
    "notFoundResponse",
    ()=>notFoundResponse,
    "rateLimitResponse",
    ()=>rateLimitResponse,
    "successResponse",
    ()=>successResponse,
    "validationErrorResponse",
    ()=>validationErrorResponse
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/types.ts [app-route] (ecmascript)");
;
;
function successResponse(data, status = 200) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        success: true,
        data
    }, {
        status
    });
}
function errorResponse(code, message, status = 400, details) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        success: false,
        error: {
            code,
            message,
            ...("TURBOPACK compile-time value", "development") === 'development' && details ? {
                details
            } : {}
        }
    }, {
        status
    });
}
function validationErrorResponse(message, details) {
    return errorResponse(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ErrorCodes"].VALIDATION_ERROR, message, 400, details);
}
function notFoundResponse(message = '资源不存在') {
    return errorResponse(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ErrorCodes"].NOT_FOUND, message, 404);
}
function rateLimitResponse(message = '请求过于频繁，请稍后再试') {
    return errorResponse(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ErrorCodes"].RATE_LIMIT, message, 429);
}
function internalErrorResponse(message = '服务器内部错误', details) {
    return errorResponse(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ErrorCodes"].INTERNAL_ERROR, message, 500, details);
}
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/lib/api/data.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * 数据访问层
 */ __turbopack_context__.s([
    "getContactSubmissionCount",
    ()=>getContactSubmissionCount,
    "getProjectBySlug",
    ()=>getProjectBySlug,
    "getProjects",
    ()=>getProjects,
    "saveContactSubmission",
    ()=>saveContactSubmission
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
const PROJECTS_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), 'data', 'projects.json');
async function getProjects() {
    try {
        const fileContent = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(PROJECTS_FILE, 'utf-8');
        return JSON.parse(fileContent);
    } catch (error) {
        console.error('Failed to read projects.json:', error);
        return [];
    }
}
async function getProjectBySlug(slug) {
    const projects = await getProjects();
    return projects.find((p)=>p.slug === slug) || null;
}
const contactSubmissions = [];
function saveContactSubmission(data) {
    const submission = {
        id: `contact_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        ...data,
        createdAt: new Date().toISOString()
    };
    contactSubmissions.push(submission);
    // 可选：追加到文件（用于持久化）
    // 生产环境建议使用数据库
    return submission;
}
function getContactSubmissionCount() {
    return contactSubmissions.length;
}
}),
"[project]/lib/api/rateLimit.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * 简单的 Rate Limit 实现（内存存储）
 * 生产环境建议使用 Redis 或专业限流中间件
 */ __turbopack_context__.s([
    "checkRateLimit",
    ()=>checkRateLimit,
    "getClientIP",
    ()=>getClientIP
]);
// 内存存储：IP -> 限流记录
const rateLimitStore = new Map();
// 清理过期记录（每5分钟执行一次）
if (typeof setInterval !== 'undefined') {
    setInterval(()=>{
        const now = Date.now();
        for (const [key, entry] of rateLimitStore.entries()){
            if (now > entry.resetTime) {
                rateLimitStore.delete(key);
            }
        }
    }, 5 * 60 * 1000);
}
const defaultConfig = {
    maxRequests: 5,
    windowMs: 60 * 1000
};
function checkRateLimit(identifier, config = defaultConfig) {
    const now = Date.now();
    const entry = rateLimitStore.get(identifier);
    if (!entry || now > entry.resetTime) {
        // 创建新记录或重置过期记录
        const resetTime = now + config.windowMs;
        rateLimitStore.set(identifier, {
            count: 1,
            resetTime
        });
        return {
            allowed: true,
            remaining: config.maxRequests - 1,
            resetTime
        };
    }
    // 检查是否超过限制
    if (entry.count >= config.maxRequests) {
        return {
            allowed: false,
            remaining: 0,
            resetTime: entry.resetTime
        };
    }
    // 增加计数
    entry.count++;
    return {
        allowed: true,
        remaining: config.maxRequests - entry.count,
        resetTime: entry.resetTime
    };
}
function getClientIP(request) {
    // 尝试从 headers 获取真实 IP（如果经过代理）
    const forwarded = request.headers.get('x-forwarded-for');
    if (forwarded) {
        return forwarded.split(',')[0].trim();
    }
    const realIP = request.headers.get('x-real-ip');
    if (realIP) {
        return realIP;
    }
    // 降级到 localhost（开发环境）
    return 'localhost';
}
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/net [external] (net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}),
"[externals]/dns [external] (dns, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("dns", () => require("dns"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/tls [external] (tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}),
"[externals]/child_process [external] (child_process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("child_process", () => require("child_process"));

module.exports = mod;
}),
"[project]/lib/api/email.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * 邮件服务模块
 * 使用 nodemailer 发送邮件
 */ __turbopack_context__.s([
    "sendContactNotification",
    ()=>sendContactNotification,
    "sendEmail",
    ()=>sendEmail
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nodemailer$2f$lib$2f$nodemailer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/nodemailer/lib/nodemailer.js [app-route] (ecmascript)");
;
/**
 * 创建邮件传输器
 */ function createTransporter() {
    // 从环境变量读取配置
    const smtpHost = process.env.SMTP_HOST || 'smtp.qq.com';
    const smtpPort = parseInt(process.env.SMTP_PORT || '465', 10);
    const smtpSecure = process.env.SMTP_SECURE !== 'false'; // 默认 true (SSL)
    const smtpUser = process.env.SMTP_USER;
    const smtpPass = process.env.SMTP_PASS;
    // 检查必要的配置
    if (!smtpUser || !smtpPass) {
        console.warn('邮件服务未配置：缺少 SMTP_USER 或 SMTP_PASS 环境变量');
        return null;
    }
    const config = {
        host: smtpHost,
        port: smtpPort,
        secure: smtpSecure,
        auth: {
            user: smtpUser,
            pass: smtpPass
        }
    };
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nodemailer$2f$lib$2f$nodemailer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].createTransport(config);
}
async function sendEmail(options) {
    const transporter = createTransporter();
    if (!transporter) {
        console.error('邮件服务未配置，无法发送邮件');
        return false;
    }
    try {
        const info = await transporter.sendMail({
            from: `"作品集网站" <${process.env.SMTP_USER}>`,
            to: options.to,
            subject: options.subject,
            html: options.html,
            text: options.text || options.html.replace(/<[^>]*>/g, '')
        });
        console.log('邮件发送成功:', info.messageId);
        return true;
    } catch (error) {
        console.error('邮件发送失败:', error);
        return false;
    }
}
async function sendContactNotification(data) {
    const recipientEmail = process.env.CONTACT_RECIPIENT_EMAIL || '923206295@qq.com';
    const subject = `【作品集网站】新的联系表单提交 - ${data.name}`;
    const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #2563eb; color: white; padding: 20px; border-radius: 8px 8px 0 0; }
        .content { background: #f6f7f9; padding: 20px; border-radius: 0 0 8px 8px; }
        .field { margin-bottom: 15px; }
        .label { font-weight: bold; color: #475569; margin-bottom: 5px; display: block; }
        .value { background: white; padding: 10px; border-radius: 4px; border: 1px solid #e2e8f0; }
        .message-box { background: white; padding: 15px; border-radius: 4px; border: 1px solid #e2e8f0; white-space: pre-wrap; }
        .footer { margin-top: 20px; padding-top: 20px; border-top: 1px solid #e2e8f0; font-size: 12px; color: #475569; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h2 style="margin: 0;">新的联系表单提交</h2>
        </div>
        <div class="content">
          <div class="field">
            <span class="label">姓名：</span>
            <div class="value">${escapeHtml(data.name)}</div>
          </div>
          <div class="field">
            <span class="label">邮箱：</span>
            <div class="value">${escapeHtml(data.email)}</div>
          </div>
          <div class="field">
            <span class="label">消息内容：</span>
            <div class="message-box">${escapeHtml(data.message)}</div>
          </div>
          <div class="footer">
            <p>此邮件来自作品集网站联系表单，发送时间：${new Date().toLocaleString('zh-CN')}</p>
            <p>回复此邮件可直接联系：<a href="mailto:${data.email}">${data.email}</a></p>
          </div>
        </div>
      </div>
    </body>
    </html>
  `;
    return sendEmail({
        to: recipientEmail,
        subject,
        html
    });
}
/**
 * HTML 转义函数（防止 XSS）
 */ function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, (m)=>map[m]);
}
}),
"[project]/app/api/contact/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * POST /api/contact
 * 联系表单提交接口
 */ __turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$schemas$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/schemas.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/response.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$data$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/data.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$rateLimit$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/rateLimit.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$email$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/email.ts [app-route] (ecmascript)");
;
;
;
;
;
async function POST(request) {
    try {
        // Rate Limit 检查
        const clientIP = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$rateLimit$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getClientIP"])(request);
        const rateLimitResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$rateLimit$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["checkRateLimit"])(`contact:${clientIP}`, {
            maxRequests: 5,
            windowMs: 60 * 1000
        });
        if (!rateLimitResult.allowed) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["rateLimitResponse"])(`请求过于频繁，请 ${Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)} 秒后再试`);
        }
        // 解析请求体
        let body;
        try {
            body = await request.json();
        } catch (error) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["validationErrorResponse"])('请求体格式错误，需要 JSON 格式');
        }
        // 校验请求数据
        const validationResult = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$schemas$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["contactRequestSchema"].safeParse(body);
        if (!validationResult.success) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["validationErrorResponse"])('表单数据校验失败', validationResult.error.issues);
        }
        const { name, email, message } = validationResult.data;
        // 保存提交（内存存储）
        const submission = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$data$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["saveContactSubmission"])({
            name,
            email,
            message
        });
        // 发送邮件通知
        try {
            const emailSent = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$email$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sendContactNotification"])({
                name,
                email,
                message
            });
            if (!emailSent) {
                console.warn('邮件发送失败，但表单已保存');
            // 即使邮件发送失败，也返回成功（表单已保存）
            }
        } catch (error) {
            console.error('发送邮件时出错:', error);
        // 邮件发送失败不影响表单提交成功
        }
        // 返回成功响应
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["successResponse"])({
            id: submission.id,
            createdAt: submission.createdAt
        }, 201);
    } catch (error) {
        console.error('POST /api/contact error:', error);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["internalErrorResponse"])('提交联系表单失败', error);
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__c87a64f2._.js.map