module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/lib/api/content.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * 内容数据访问层
 */ __turbopack_context__.s([
    "clearContentCache",
    ()=>clearContentCache,
    "getContentData",
    ()=>getContentData
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
const CONTENT_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), 'data', 'content.json');
let cachedContent = null;
let cacheTimestamp = 0;
const CACHE_TTL = 5 * 60 * 1000; // 5 分钟缓存
async function getContentData() {
    const now = Date.now();
    // 如果缓存有效，直接返回
    if (cachedContent && now - cacheTimestamp < CACHE_TTL) {
        return cachedContent;
    }
    try {
        const fileContent = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(CONTENT_FILE, 'utf-8');
        const data = JSON.parse(fileContent);
        // 更新缓存
        cachedContent = data;
        cacheTimestamp = now;
        return data;
    } catch (error) {
        console.error('Failed to read content.json:', error);
        throw new Error('Failed to load content data');
    }
}
function clearContentCache() {
    cachedContent = null;
    cacheTimestamp = 0;
}
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/lib/api/types.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * API 共享类型定义
 */ // ========== 统一响应格式 ==========
__turbopack_context__.s([
    "ErrorCodes",
    ()=>ErrorCodes
]);
const ErrorCodes = {
    VALIDATION_ERROR: 'VALIDATION_ERROR',
    NOT_FOUND: 'NOT_FOUND',
    RATE_LIMIT: 'RATE_LIMIT',
    INTERNAL_ERROR: 'INTERNAL_ERROR'
};
}),
"[project]/lib/api/response.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * 统一响应工具函数
 */ __turbopack_context__.s([
    "errorResponse",
    ()=>errorResponse,
    "internalErrorResponse",
    ()=>internalErrorResponse,
    "notFoundResponse",
    ()=>notFoundResponse,
    "rateLimitResponse",
    ()=>rateLimitResponse,
    "successResponse",
    ()=>successResponse,
    "validationErrorResponse",
    ()=>validationErrorResponse
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/types.ts [app-route] (ecmascript)");
;
;
function successResponse(data, status = 200) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        success: true,
        data
    }, {
        status
    });
}
function errorResponse(code, message, status = 400, details) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        success: false,
        error: {
            code,
            message,
            ...("TURBOPACK compile-time value", "development") === 'development' && details ? {
                details
            } : {}
        }
    }, {
        status
    });
}
function validationErrorResponse(message, details) {
    return errorResponse(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ErrorCodes"].VALIDATION_ERROR, message, 400, details);
}
function notFoundResponse(message = '资源不存在') {
    return errorResponse(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ErrorCodes"].NOT_FOUND, message, 404);
}
function rateLimitResponse(message = '请求过于频繁，请稍后再试') {
    return errorResponse(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ErrorCodes"].RATE_LIMIT, message, 429);
}
function internalErrorResponse(message = '服务器内部错误', details) {
    return errorResponse(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ErrorCodes"].INTERNAL_ERROR, message, 500, details);
}
}),
"[project]/app/api/resume/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * GET /api/resume
 * 获取简历页面内容
 */ __turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$content$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/content.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/response.ts [app-route] (ecmascript)");
;
;
async function GET(request) {
    try {
        const content = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$content$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getContentData"])();
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["successResponse"])(content.resume);
    } catch (error) {
        console.error('GET /api/resume error:', error);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["internalErrorResponse"])('获取简历内容失败', error);
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__40e644ae._.js.map