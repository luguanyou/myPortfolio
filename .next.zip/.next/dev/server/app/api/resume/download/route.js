var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/resume/download/route.js")
R.c("server/chunks/node_modules_next_6fbd0584._.js")
R.c("server/chunks/[root-of-the-server]__28d0a526._.js")
R.c("server/chunks/_next-internal_server_app_api_resume_download_route_actions_79304aca.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/resume/download/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/resume/download/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
