var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact/route.js")
R.c("server/chunks/node_modules_next_7f9493a0._.js")
R.c("server/chunks/node_modules_zod_v4_2bfd4e57._.js")
R.c("server/chunks/node_modules_nodemailer_f0e2e4c8._.js")
R.c("server/chunks/[root-of-the-server]__c87a64f2._.js")
R.c("server/chunks/_next-internal_server_app_api_contact_route_actions_0bce5875.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/contact/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/contact/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
