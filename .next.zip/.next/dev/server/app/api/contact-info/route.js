var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact-info/route.js")
R.c("server/chunks/node_modules_next_8136b3c3._.js")
R.c("server/chunks/[root-of-the-server]__cec7129c._.js")
R.c("server/chunks/_next-internal_server_app_api_contact-info_route_actions_d53a99e1.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/contact-info/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/contact-info/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
