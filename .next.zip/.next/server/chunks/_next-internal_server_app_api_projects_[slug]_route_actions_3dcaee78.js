module.exports=[70101,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_projects_%5Bslug%5D_route_actions_3dcaee78.js.map