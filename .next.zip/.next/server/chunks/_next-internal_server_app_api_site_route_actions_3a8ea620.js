module.exports=[68221,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_site_route_actions_3a8ea620.js.map