module.exports=[88614,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_contact-info_route_actions_d53a99e1.js.map