var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/site/route.js")
R.c("server/chunks/[root-of-the-server]__1f5dd8f7._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_site_route_actions_3a8ea620.js")
R.m(54746)
module.exports=R.m(54746).exports
