var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/home/route.js")
R.c("server/chunks/[root-of-the-server]__5302e644._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_home_route_actions_d2af12c6.js")
R.m(29666)
module.exports=R.m(29666).exports
