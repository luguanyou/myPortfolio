var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/projects/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__436e20bd._.js")
R.c("server/chunks/lib_api_4dd80660._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_projects_[slug]_route_actions_3dcaee78.js")
R.m(23907)
module.exports=R.m(23907).exports
