var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/projects/route.js")
R.c("server/chunks/[root-of-the-server]__a60f61f2._.js")
R.c("server/chunks/lib_api_4dd80660._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_projects_route_actions_38c611ee.js")
R.m(22321)
module.exports=R.m(22321).exports
