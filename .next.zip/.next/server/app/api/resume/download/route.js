var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/resume/download/route.js")
R.c("server/chunks/[root-of-the-server]__f942ddaf._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_resume_download_route_actions_79304aca.js")
R.m(56979)
module.exports=R.m(56979).exports
